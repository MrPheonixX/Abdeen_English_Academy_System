import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ChartNoAxesColumn, a as Square, c as Moon, d as ListChecks, f as Library, g as Compass, h as ExternalLink, i as Sun, l as Mic, m as Flag, o as Route, p as House, r as Timer, s as NotebookPen, t as X, u as Menu, v as BookOpen, y as AudioLines } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D40g-NjI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LESSONS = [
	{
		n: 1,
		alid: 2001,
		title: "Basic usage of 'I'm'",
		section: 1
	},
	{
		n: 2,
		alid: 2002,
		title: "Variations of 'I'm in/at/on'",
		section: 1
	},
	{
		n: 3,
		alid: 2003,
		title: "I'm good at",
		section: 1
	},
	{
		n: 4,
		alid: 2005,
		title: "I'm + (verb)",
		section: 1
	},
	{
		n: 5,
		alid: 2006,
		title: "I'm getting",
		section: 1
	},
	{
		n: 6,
		alid: 2007,
		title: "I'm trying + (verb)",
		section: 1
	},
	{
		n: 7,
		alid: 2008,
		title: "I'm gonna + (verb)",
		section: 1
	},
	{
		n: 8,
		alid: 2009,
		title: "I have + (noun)",
		section: 1
	},
	{
		n: 9,
		alid: 2010,
		title: "I have + (past participle)",
		section: 1
	},
	{
		n: 10,
		alid: 2011,
		title: "I used to + (verb)",
		section: 1
	},
	{
		n: 11,
		alid: 2012,
		title: "I have to + (verb)",
		section: 1
	},
	{
		n: 12,
		alid: 2013,
		title: "I wanna + (verb)",
		section: 1
	},
	{
		n: 13,
		alid: 2014,
		title: "I gotta + (verb)",
		section: 1
	},
	{
		n: 14,
		alid: 2015,
		title: "I would like to + (verb)",
		section: 1
	},
	{
		n: 15,
		alid: 2016,
		title: "I plan to + (verb)",
		section: 1
	},
	{
		n: 16,
		alid: 2017,
		title: "I've decided to + (verb)",
		section: 1
	},
	{
		n: 17,
		alid: 2018,
		title: "I was about to + (verb)",
		section: 1
	},
	{
		n: 18,
		alid: 2019,
		title: "I didn't mean to + (verb)",
		section: 1
	},
	{
		n: 19,
		alid: 2020,
		title: "I don't have time to + (verb)",
		section: 1
	},
	{
		n: 20,
		alid: 2021,
		title: "I promise not to + (verb)",
		section: 1
	},
	{
		n: 21,
		alid: 2022,
		title: "I'd rather + (verb)",
		section: 1
	},
	{
		n: 22,
		alid: 2023,
		title: "I feel like + (verb-ing)",
		section: 1
	},
	{
		n: 23,
		alid: 2024,
		title: "I can't help + (verb-ing)",
		section: 1
	},
	{
		n: 24,
		alid: 2025,
		title: "I was busy + (verb-ing)",
		section: 1
	},
	{
		n: 25,
		alid: 2026,
		title: "I'm not used to + (verb-ing)",
		section: 1
	},
	{
		n: 26,
		alid: 2027,
		title: "I want you to + (verb)",
		section: 1
	},
	{
		n: 27,
		alid: 2028,
		title: "I'm here to + (verb)",
		section: 1
	},
	{
		n: 28,
		alid: 2029,
		title: "I have something + (verb)",
		section: 1
	},
	{
		n: 29,
		alid: 2030,
		title: "I'm looking forward to",
		section: 1
	},
	{
		n: 30,
		alid: 2031,
		title: "I'm calling to + (verb)",
		section: 2
	},
	{
		n: 31,
		alid: 2032,
		title: "I'm working on + (noun)",
		section: 2
	},
	{
		n: 32,
		alid: 2033,
		title: "I'm sorry to + (verb)",
		section: 2
	},
	{
		n: 33,
		alid: 2034,
		title: "I'm thinking of + (verb-ing)",
		section: 2
	},
	{
		n: 34,
		alid: 2035,
		title: "I'll help you + (verb)",
		section: 2
	},
	{
		n: 35,
		alid: 2036,
		title: "I'm dying to + (verb)",
		section: 2
	},
	{
		n: 36,
		alid: 2037,
		title: "It's my turn to + (verb)",
		section: 2
	},
	{
		n: 37,
		alid: 2038,
		title: "It's hard for me to + (verb)",
		section: 2
	},
	{
		n: 38,
		alid: 2039,
		title: "I'm having a hard time + (verb-ing)",
		section: 2
	},
	{
		n: 39,
		alid: 2040,
		title: "I think I should + (verb)",
		section: 2
	},
	{
		n: 40,
		alid: 2041,
		title: "I've heard that + (subject + verb)",
		section: 2
	},
	{
		n: 41,
		alid: 2042,
		title: "It occurred to me that (subject + verb)",
		section: 2
	},
	{
		n: 42,
		alid: 2043,
		title: "Let me + (verb)",
		section: 2
	},
	{
		n: 43,
		alid: 2044,
		title: "Thank you for",
		section: 2
	},
	{
		n: 44,
		alid: 2045,
		title: "Can I + (verb)",
		section: 2
	},
	{
		n: 45,
		alid: 2046,
		title: "Can I get + (noun)",
		section: 2
	},
	{
		n: 46,
		alid: 2047,
		title: "I'm not sure if (subject + verb)",
		section: 2
	},
	{
		n: 47,
		alid: 2048,
		title: "Do you mind if I + (verb)",
		section: 2
	},
	{
		n: 48,
		alid: 2049,
		title: "I don't know what to + (verb)",
		section: 2
	},
	{
		n: 49,
		alid: 2050,
		title: "I should have + (past participle)",
		section: 2
	},
	{
		n: 50,
		alid: 2051,
		title: "I wish I could + (verb)",
		section: 2
	},
	{
		n: 51,
		alid: 2052,
		title: "You should + (verb)",
		section: 2
	},
	{
		n: 52,
		alid: 2053,
		title: "You're supposed to + (verb)",
		section: 2
	},
	{
		n: 53,
		alid: 2054,
		title: "You seem + (adjective)",
		section: 2
	},
	{
		n: 54,
		alid: 2055,
		title: "You'd better + (verb)",
		section: 2
	},
	{
		n: 55,
		alid: 2056,
		title: "Are you into + (noun)",
		section: 2
	},
	{
		n: 56,
		alid: 2057,
		title: "Are you trying to + (verb)",
		section: 2
	},
	{
		n: 57,
		alid: 2058,
		title: "Please + (verb)",
		section: 2
	},
	{
		n: 58,
		alid: 2059,
		title: "Don't + (verb)",
		section: 2
	},
	{
		n: 59,
		alid: 2060,
		title: "Do you like",
		section: 2
	},
	{
		n: 60,
		alid: 2061,
		title: "How often do you",
		section: 3
	},
	{
		n: 61,
		alid: 2062,
		title: "Do you want me to + (verb)",
		section: 3
	},
	{
		n: 62,
		alid: 2063,
		title: "What do you think about (verb-ing)",
		section: 3
	},
	{
		n: 63,
		alid: 2064,
		title: "Why don't we + (verb)",
		section: 3
	},
	{
		n: 64,
		alid: 2065,
		title: "It's too bad that",
		section: 3
	},
	{
		n: 65,
		alid: 2066,
		title: "You could have + (past participle)",
		section: 3
	},
	{
		n: 66,
		alid: 2067,
		title: "If I were you, I would + (verb)",
		section: 3
	},
	{
		n: 67,
		alid: 2068,
		title: "It's gonna be + (adjective)",
		section: 3
	},
	{
		n: 68,
		alid: 2069,
		title: "It looks like + (noun)",
		section: 3
	},
	{
		n: 69,
		alid: 2070,
		title: "That's why + (subject + verb)",
		section: 3
	},
	{
		n: 70,
		alid: 2071,
		title: "It's time to + (verb)",
		section: 3
	},
	{
		n: 71,
		alid: 2072,
		title: "The point is that + (subject + verb)",
		section: 3
	},
	{
		n: 72,
		alid: 2073,
		title: "How was + (noun)",
		section: 3
	},
	{
		n: 73,
		alid: 2074,
		title: "How about + (verb-ing)",
		section: 3
	},
	{
		n: 74,
		alid: 2075,
		title: "What if + (subject + verb)",
		section: 3
	},
	{
		n: 75,
		alid: 2076,
		title: "How much does it cost to + (verb)",
		section: 3
	},
	{
		n: 76,
		alid: 2077,
		title: "How come + (subject + verb)",
		section: 3
	},
	{
		n: 77,
		alid: 2078,
		title: "What are the chances of + (verb-ing)",
		section: 3
	},
	{
		n: 78,
		alid: 2079,
		title: "There is something wrong with + (noun)",
		section: 3
	},
	{
		n: 79,
		alid: 2080,
		title: "Let's not + (verb)",
		section: 3
	},
	{
		n: 80,
		alid: 2081,
		title: "Let's say that + (subject + verb)",
		section: 3
	},
	{
		n: 81,
		alid: 2082,
		title: "There's no need to + (verb)",
		section: 3
	},
	{
		n: 82,
		alid: 2083,
		title: "It takes + (time) + to + (verb)",
		section: 3
	},
	{
		n: 83,
		alid: 2084,
		title: "Please make sure that + (subject + verb)",
		section: 3
	},
	{
		n: 84,
		alid: 2085,
		title: "Here's to + (noun)",
		section: 3
	},
	{
		n: 85,
		alid: 2086,
		title: "It's no use + (verb-ing)",
		section: 3
	},
	{
		n: 86,
		alid: 2087,
		title: "There's no way + (subject + verb)",
		section: 3
	},
	{
		n: 87,
		alid: 2088,
		title: "It's very kind of you to + (verb)",
		section: 3
	},
	{
		n: 88,
		alid: 2089,
		title: "There's nothing + (subject) + can + (verb)",
		section: 3
	},
	{
		n: 89,
		alid: 2090,
		title: "Rumor has it that + (subject + verb)",
		section: 3
	}
];
var LESSON_COUNT = LESSONS.length;
function lessonHref(alid) {
	return `https://www.talkenglish.com/lessondetails.aspx?ALID=${alid}`;
}
function lessonsFrom(next, count = 3) {
	if (next > LESSON_COUNT) return [];
	const start = Math.max(1, next);
	return LESSONS.slice(start - 1, start - 1 + count);
}
var FLOW = [
	"review",
	"te",
	"news1",
	"news2",
	"news3",
	"vocab",
	"tw",
	"msa",
	"shadow",
	"game",
	"mock",
	"discord"
];
var RECOVERY_REQUIRED = [
	"review",
	"te",
	"tw",
	"discord"
];
var NORMAL_REQUIRED = [
	...RECOVERY_REQUIRED,
	"news1",
	"news2",
	"news3",
	"vocab",
	"shadow",
	"msa"
];
function taskSplit(mode) {
	if (mode === "s") return {
		required: RECOVERY_REQUIRED,
		bonus: [
			"shadow",
			"msa",
			"game"
		]
	};
	if (mode === "n") return {
		required: NORMAL_REQUIRED,
		bonus: ["game"]
	};
	return {
		required: [
			...NORMAL_REQUIRED,
			"game",
			"mock"
		],
		bonus: []
	};
}
function orderedTasks(mode) {
	const { required, bonus } = taskSplit(mode);
	const inMode = /* @__PURE__ */ new Set([...required, ...bonus]);
	return FLOW.filter((id) => inMode.has(id)).map((id) => ({
		id,
		optional: bonus.includes(id)
	}));
}
var MODES = [
	{
		id: "s",
		name: "Recovery",
		time: "50–60 min",
		line: "Four things: yesterday’s words, 3 lessons, tongue twisters, 30 minutes on Discord."
	},
	{
		id: "n",
		name: "Normal",
		time: "1–2 h",
		line: "Add the articles, your sentences, a short shadow, and My Story Animated in blocks."
	},
	{
		id: "o",
		name: "Day off",
		time: "3–4 h",
		line: "Full hour of My Story Animated, a customer-call drill, then Discord."
	}
];
function modeMeta(mode) {
	return MODES.find((m) => m.id === mode) ?? MODES[1];
}
function taskCopy(id, mode, teNext) {
	const batch = lessonsFrom(teNext);
	const range = batch.length === 0 ? "" : batch.length === 1 ? `Lesson ${batch[0].n}` : `Lessons ${batch[0].n}–${batch[batch.length - 1].n}`;
	switch (id) {
		case "review": return {
			title: "Morning: review yesterday’s words",
			detail: "Say the word and your own sentence out loud. Do not reread in silence.",
			links: []
		};
		case "te":
			if (batch.length === 0) return {
				title: "TalkEnglish: 3 Regular English lessons",
				detail: `Speaking Basics is finished (${LESSON_COUNT}/${LESSON_COUNT}). Same rule: listen to each sentence, repeat it, then say it without looking.`,
				links: [{
					href: "https://www.talkenglish.com/speaking/listregular.aspx",
					label: "Open Regular English"
				}]
			};
			return {
				title: `TalkEnglish: 3 lessons in order — ${range}`,
				detail: "Open each lesson. Tap every sentence, listen, repeat, then say it without looking. Do not only read.",
				links: batch.map((lesson) => ({
					href: `https://www.talkenglish.com/lessondetails.aspx?ALID=${lesson.alid}`,
					label: `${lesson.n}. ${lesson.title}`
				}))
			};
		case "tw": return {
			title: "Tongue twisters on the way",
			detail: "engVid 1, 2, 3, 21 and 22, plus your two starters. Hear it, copy it slowly, then at normal speed. Clean sound before fast speed.",
			links: [{
				href: "https://www.engvid.com/english-resource/50-tongue-twisters-improve-pronunciation/",
				label: "engVid list"
			}]
		};
		case "news1":
		case "news2":
		case "news3": {
			const n = id === "news1" ? 1 : id === "news2" ? 2 : 3;
			return {
				title: `News in Levels, Level 2 — article ${n}`,
				detail: n === 1 ? "Open it on the computer. Read it aloud. Record your voice on your phone." : n === 2 ? "Read aloud and record. Do not chase every unknown word." : "Read aloud and record. Keep useful phrases, not single words.",
				links: n === 1 ? [{
					href: "https://www.newsinlevels.com/level/level-2/",
					label: "Level 2"
				}] : []
			};
		}
		case "vocab": return {
			title: "Write a sentence for each phrase you keep",
			detail: "One natural sentence, in the Words tab. Yours, not a copied example.",
			links: []
		};
		case "msa": return {
			title: mode === "o" ? "My Story Animated — full 60 minutes" : "My Story Animated — listening block",
			detail: mode === "o" ? "One full hour. English only. Pause and imitate how they speak. No Arabic subtitles." : mode === "s" ? "Optional. One short story if you still have energy. Imitate a few lines." : "Target 60 minutes, split into 20–30 minute blocks around the shift. Imitate short lines. No Arabic subtitles.",
			links: [{
				href: "https://www.youtube.com/results?search_query=my+story+animated",
				label: "Open My Story Animated"
			}]
		};
		case "shadow": return {
			title: "5-minute shadow",
			detail: "Friends, English-dubbed anime, American animation, or your clip. Copy rhythm and pauses. Do not translate.",
			links: [{
				href: "https://youtu.be/vHBrMxIEEwY",
				label: "Your clip"
			}, {
				href: "https://www.youtube.com/playlist?list=PLp22-4PivYmIiXGqtQMrfE_tzmqE6r7Tc",
				label: "Playlist"
			}]
		};
		case "game": return {
			title: "Game or show, English only",
			detail: "Arabic subtitles stay off. Meaning comes from the scene, the words, and what people do. Tick this only if you actually kept the rule.",
			links: []
		};
		case "discord": return {
			title: "Discord — at least 30 minutes, last",
			detail: "Talk with foreigners. No script. This is the daily speaking check. Scrolling the server does not count.",
			links: []
		};
		case "mock": return {
			title: "Customer-call drill — 3 to 10 minutes",
			detail: "Record it. Greeting, question, explanation, empathy, close. Then listen back for th, speed, and long pauses.",
			links: []
		};
	}
}
var RANKS = [
	{
		xp: 0,
		name: "Rookie"
	},
	{
		xp: 250,
		name: "Explorer"
	},
	{
		xp: 700,
		name: "Speaker"
	},
	{
		xp: 1600,
		name: "Storyteller"
	},
	{
		xp: 3200,
		name: "Job Ready"
	}
];
function rankFor(xp) {
	let index = 0;
	RANKS.forEach((rank, i) => {
		if (xp >= rank.xp) index = i;
	});
	const current = RANKS[index];
	const next = RANKS[index + 1];
	const span = next ? next.xp - current.xp : 1;
	const into = next ? xp - current.xp : 1;
	return {
		current,
		next,
		pct: next ? Math.max(0, Math.min(100, into / span * 100)) : 100
	};
}
var LEVELS = [
	{
		name: "Foundation",
		body: "Get the speaking reflex back. TalkEnglish every day, sound work, reading aloud, a short shadow, and a real conversation.",
		test: "Record 2 minutes of unscripted speech. th and s/z are clear enough to understand."
	},
	{
		name: "Rebuild",
		body: "Turn recognition back into automatic speech. Keep the 3-lesson routine. Shadow more. Talk to people, not only to a screen.",
		test: "Hold a 15-minute Discord conversation without switching to Arabic."
	},
	{
		name: "Job Ready",
		body: "Call-centre English: faster listening, simple customer phrases, empathy, questions, explanations, and a clean close.",
		test: "Record a 10-minute customer call. Listen back for pauses, pronunciation, and clarity."
	}
];
var CHECKS = [
	"I can say think and this with the right tongue position and voice.",
	"I can speak for 2 minutes without stopping or switching to Arabic.",
	"I can follow an English show or animation without Arabic subtitles most of the time.",
	"I can hold a 15-minute conversation with a stranger in English.",
	"I can handle a customer call in English."
];
var DAILY_TWISTERS = [
	{
		id: "1",
		label: "1 — Peter Piper",
		why: "P sound and rhythm. Daily set.",
		lines: [
			"Peter Piper picked a peck of pickled peppers.",
			"A peck of pickled peppers Peter Piper picked.",
			"If Peter Piper picked a peck of pickled peppers,",
			"Where's the peck of pickled peppers Peter Piper picked?"
		]
	},
	{
		id: "2",
		label: "2 — Betty Botter",
		why: "B and the short vowels. Daily set.",
		lines: [
			"Betty Botter bought some butter",
			"But she said the butter’s bitter",
			"If I put it in my batter, it will make my batter bitter",
			"But a bit of better butter will make my batter better",
			"So ’twas better Betty Botter bought a bit of better butter"
		]
	},
	{
		id: "3",
		label: "3 — Woodchuck",
		why: "W and speed, only after it is clean. Daily set.",
		lines: [
			"How much wood would a woodchuck chuck if a woodchuck could chuck wood?",
			"He would chuck, he would, as much as he could, and chuck as much wood",
			"As a woodchuck would if a woodchuck could chuck wood"
		]
	},
	{
		id: "21",
		label: "21 — TH drill",
		why: "Tongue tip between the teeth. Your th practice.",
		lines: ["Tom threw Tim three thumbtacks."]
	},
	{
		id: "22",
		label: "22 — TH / F",
		why: "th versus f. Do not let threw become free.",
		lines: ["He threw three free throws."]
	}
];
var STARTER_TWISTERS = [{
	id: "coffee",
	label: "Your starter — copper coffee pot",
	why: "P, and the rhythm of a longer line.",
	lines: [
		"All I want is a proper cup of coffee.",
		"Made in a proper copper coffee pot.",
		"You can believe it or not.",
		"But I want a cup of coffee from a proper copper pot."
	]
}, {
	id: "thinkers",
	label: "Your starter — thousand thinkers",
	why: "th at the start of a crowded line.",
	lines: ["There those thousand thinkers were thinking how did the other three thieves go through."]
}];
var ALL_TWISTERS = [...DAILY_TWISTERS, ...STARTER_TWISTERS];
var SOUNDS = [
	{
		title: "th — no voice",
		how: "Tongue tip between the teeth. Air only. No buzz in the throat. think, not sink.",
		words: [
			"think",
			"thing",
			"three",
			"thank"
		]
	},
	{
		title: "th — with voice",
		how: "Same tongue. Add a buzz in the throat. this, not dis. Touch your throat: it should vibrate.",
		words: [
			"this",
			"that",
			"those",
			"the"
		]
	},
	{
		title: "s versus z",
		how: "Same mouth shape. z adds the buzz. sip / zip. price / prize.",
		words: [
			"sip",
			"zip",
			"sue",
			"zoo",
			"price",
			"prize"
		]
	},
	{
		title: "b versus p",
		how: "Lips closed. b is voiced and softer. p is a puff of air.",
		words: [
			"big",
			"pig",
			"back",
			"pack",
			"bear",
			"pear"
		]
	}
];
var RESOURCES = [
	{
		title: "TalkEnglish — Speaking Basics",
		detail: "89 lessons on the site. Your rule: 3 a day, in order.",
		href: "https://www.talkenglish.com/speaking/listbasics.aspx"
	},
	{
		title: "TalkEnglish — Basics I",
		detail: "Lessons 1–29. Common sentences, from I’m.",
		href: "https://www.talkenglish.com/speaking/basics/speaking_basics_i.aspx"
	},
	{
		title: "TalkEnglish — Basics II",
		detail: "Lessons 30–59.",
		href: "https://www.talkenglish.com/speaking/basics/speaking_basics_ii.aspx"
	},
	{
		title: "TalkEnglish — Basics III",
		detail: "Lessons 60–89.",
		href: "https://www.talkenglish.com/speaking/basics/speaking_basics_iii.aspx"
	},
	{
		title: "TalkEnglish — how to study a lesson",
		detail: "Listen, repeat, then speak as Person A and Person B.",
		href: "https://www.talkenglish.com/instruction.aspx"
	},
	{
		title: "TalkEnglish — Listening",
		detail: "Extra listening. Not a replacement for the 3 speaking lessons.",
		href: "https://www.talkenglish.com/listening/listregular.aspx"
	},
	{
		title: "TalkEnglish — Regular English",
		detail: "Only after Speaking Basics feels automatic.",
		href: "https://www.talkenglish.com/speaking/listregular.aspx"
	},
	{
		title: "TalkEnglish — Pronunciation",
		detail: "Extra sound lessons when one sound keeps breaking.",
		href: "https://www.talkenglish.com/extralessons/pronunciation.aspx"
	},
	{
		title: "TalkEnglish — 5 Rules for Speaking Fluency",
		detail: "Read once. Then go back to speaking.",
		href: "https://www.talkenglish.com/extralessons/speakingrules.aspx"
	},
	{
		title: "TalkEnglish — offline download",
		detail: "For the commute when the signal drops.",
		href: "https://www.talkenglish.com/english-download.aspx"
	},
	{
		title: "engVid — 50 tongue twisters",
		detail: "Your numbers are 1, 2, 3, 21 and 22.",
		href: "https://www.engvid.com/english-resource/50-tongue-twisters-improve-pronunciation/"
	},
	{
		title: "engVid",
		detail: "Video lessons. Open one only when a real gap shows up.",
		href: "https://www.engvid.com/"
	},
	{
		title: "News in Levels — Level 2",
		detail: "Three articles. Computer open, phone recording.",
		href: "https://www.newsinlevels.com/level/level-2/"
	},
	{
		title: "My Story Animated",
		detail: "60 minutes of listening. Imitate. No Arabic subtitles.",
		href: "https://www.youtube.com/results?search_query=my+story+animated"
	},
	{
		title: "Your shadowing clip",
		detail: "The video you saved.",
		href: "https://youtu.be/vHBrMxIEEwY"
	},
	{
		title: "Your shadowing playlist",
		detail: "The playlist you saved.",
		href: "https://www.youtube.com/playlist?list=PLp22-4PivYmIiXGqtQMrfE_tzmqE6r7Tc"
	},
	{
		title: "TalkEnglish — Interview English",
		detail: "Later, when you actually start applying.",
		href: "https://www.talkenglish.com/speaking/listinterview.aspx"
	}
];
var CALL_STEPS = [
	"Greet them and say your name.",
	"Ask what they need. Let them finish.",
	"Explain the situation in short sentences.",
	"Show you understand that they are upset.",
	"Give the next step, then close and thank them."
];
var CALL_MODEL = [
	"Hello, thank you for calling. My name is Ahmed. How can I help you today?",
	"I'm sorry your order is late. Let me look at that for you.",
	"I can't give a refund, but I can send a new one today.",
	"Is there anything else I can help you with? Thank you for calling."
];
var DEFAULT_REWARDS = [
	"20 minutes of an English-only game",
	"30 minutes on Discord with foreigners",
	"One guilt-free evening off"
];
function dayKey(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function shiftKey(key, delta) {
	const [y, m, d] = key.split("-").map(Number);
	const dt = new Date(y, (m ?? 1) - 1, d ?? 1);
	dt.setDate(dt.getDate() + delta);
	return dayKey(dt);
}
function weekdayShort(key) {
	const [y, m, d] = key.split("-").map(Number);
	return new Date(y, (m ?? 1) - 1, d ?? 1).toLocaleDateString("en", { weekday: "short" });
}
function monthKey(key) {
	return key.slice(0, 7);
}
var DB_NAME = "eng-academy-audio";
var STORE = "clips";
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, 1);
		req.onupgradeneeded = () => {
			if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("Could not open recordings"));
	});
}
function transactionDone(tx) {
	return new Promise((resolve, reject) => {
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error ?? /* @__PURE__ */ new Error("Recording save failed"));
		tx.onabort = () => reject(tx.error ?? /* @__PURE__ */ new Error("Recording save aborted"));
	});
}
async function saveClip(id, blob) {
	const db = await openDb();
	try {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put(blob, id);
		await transactionDone(tx);
	} finally {
		db.close();
	}
}
async function loadClip(id) {
	const db = await openDb();
	try {
		const tx = db.transaction(STORE, "readonly");
		const req = tx.objectStore(STORE).get(id);
		const blob = await new Promise((resolve, reject) => {
			req.onsuccess = () => resolve(req.result ?? null);
			req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("Could not load recording"));
		});
		await transactionDone(tx);
		return blob;
	} finally {
		db.close();
	}
}
async function deleteClip(id) {
	if (typeof indexedDB === "undefined") return;
	const db = await openDb();
	try {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).delete(id);
		await transactionDone(tx);
	} finally {
		db.close();
	}
}
var KEY = "eng-academy-v3";
var THEME_KEY = "eng-academy-theme";
var TABS = [
	"home",
	"today",
	"plan",
	"levels",
	"lab",
	"words",
	"resources",
	"notes",
	"progress",
	"check"
];
var emptyDay = () => ({
	mode: "n",
	done: [],
	rest: false
});
function defaults() {
	return {
		xp: 0,
		lv: 1,
		passed: [],
		days: {},
		words: [],
		notes: [],
		nid: 0,
		teNext: 1,
		teDone: 0,
		discLog: [],
		listenLog: [],
		shadowLog: [],
		recordings: [],
		rw: [...DEFAULT_REWARDS],
		tab: "today",
		theme: "system",
		sprintEndsAt: null
	};
}
function uid() {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
	return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
function clampLesson(n) {
	if (!Number.isFinite(n)) return 1;
	return Math.max(1, Math.min(LESSON_COUNT + 1, Math.round(n)));
}
function asMode(value) {
	if (value === "s" || value === "o" || value === "n") return value;
	if (value === "m") return "s";
	return "n";
}
var OLD_TASK = {
	l1: "te",
	l2: "te",
	l3: "te",
	rv: "review",
	tt: "tw",
	sn: "vocab",
	ar: "news1",
	a2: "news2",
	a3: "news3",
	sh: "shadow",
	li: "msa",
	fun: "game",
	dc: "discord",
	mc: "mock",
	review: "review",
	te: "te",
	tw: "tw",
	news1: "news1",
	news2: "news2",
	news3: "news3",
	vocab: "vocab",
	shadow: "shadow",
	msa: "msa",
	game: "game",
	discord: "discord",
	mock: "mock"
};
function migrateDays(raw) {
	if (!raw || typeof raw !== "object") return {};
	const days = {};
	for (const [key, value] of Object.entries(raw)) {
		if (!value || typeof value !== "object") continue;
		const row = value;
		const doneRaw = Array.isArray(row.done) ? row.done : [];
		const done = [...new Set(doneRaw.map((id) => OLD_TASK[String(id)] ?? null).filter((id) => Boolean(id)))];
		days[key] = {
			mode: asMode(row.mode),
			done,
			rest: Boolean(row.rest),
			legacyOk: Boolean(row.ok) || Boolean(row.legacyOk),
			teCredit: typeof row.teCredit === "number" ? row.teCredit : void 0,
			bonusPaid: Boolean(row.bonusPaid),
			minuteXp: row.minuteXp && typeof row.minuteXp === "object" ? row.minuteXp : void 0
		};
	}
	return days;
}
function migrateWords(raw) {
	if (!Array.isArray(raw)) return [];
	return raw.map((item, index) => {
		if (!item || typeof item !== "object") return null;
		const row = item;
		const w = String(row.w ?? "").trim();
		if (!w) return null;
		return {
			id: typeof row.id === "string" ? row.id : `w-${index}-${row.d ?? "x"}`,
			w,
			s: String(row.s ?? ""),
			d: typeof row.d === "string" ? row.d : dayKey()
		};
	}).filter((item) => Boolean(item));
}
function migrateNotes(raw) {
	if (!Array.isArray(raw)) return [];
	return raw.map((item) => {
		if (!item || typeof item !== "object") return null;
		const row = item;
		const id = Number(row.id);
		if (!Number.isFinite(id)) return null;
		return {
			id,
			t: String(row.t ?? ""),
			b: String(row.b ?? "")
		};
	}).filter((item) => Boolean(item));
}
function migrateRecordings(raw) {
	if (!Array.isArray(raw)) return [];
	const kinds = /* @__PURE__ */ new Set([
		"news",
		"twister",
		"call",
		"speak"
	]);
	return raw.map((item) => {
		if (!item || typeof item !== "object") return null;
		const row = item;
		const kind = row.kind;
		const id = typeof row.id === "string" ? row.id : "";
		const d = typeof row.d === "string" ? row.d : "";
		const seconds = Number(row.seconds);
		if (!id || !d || !kinds.has(kind) || !Number.isFinite(seconds)) return null;
		return {
			id,
			d,
			kind,
			title: String(row.title ?? "Recording").slice(0, 120),
			seconds: Math.max(1, Math.min(480, Math.round(seconds)))
		};
	}).filter((item) => Boolean(item)).slice(-24);
}
function migrateLogs(raw) {
	if (!Array.isArray(raw)) return [];
	return raw.map((item) => {
		if (!item || typeof item !== "object") return null;
		const row = item;
		const m = Number(row.m);
		const d = typeof row.d === "string" ? row.d : "";
		if (!d || !Number.isFinite(m) || m <= 0) return null;
		return {
			d,
			m: Math.round(m)
		};
	}).filter((item) => Boolean(item));
}
function sanitize(raw) {
	if (!raw || typeof raw !== "object") return null;
	const row = raw;
	const base = defaults();
	const tab = TABS.includes(row.tab) ? row.tab : "today";
	const theme = row.theme === "light" || row.theme === "dark" || row.theme === "system" ? row.theme : "system";
	const rw = Array.isArray(row.rw) ? row.rw.map((item) => String(item ?? "")) : base.rw;
	while (rw.length < 3) rw.push(DEFAULT_REWARDS[rw.length] ?? "");
	return {
		xp: Math.max(0, Number(row.xp) || 0),
		lv: Math.min(3, Math.max(1, Number(row.lv) || 1)),
		passed: Array.isArray(row.passed) ? row.passed.map(Number).filter((n) => n === 1 || n === 2 || n === 3) : [],
		days: migrateDays(row.days),
		words: migrateWords(row.words),
		notes: migrateNotes(row.notes),
		nid: Number(row.nid) || 0,
		teNext: clampLesson(Number(row.teNext) || 1),
		teDone: Math.max(0, Math.min(LESSON_COUNT, Number(row.teDone) || 0)),
		discLog: migrateLogs(row.discLog),
		listenLog: migrateLogs(row.listenLog),
		shadowLog: migrateLogs(row.shadowLog),
		recordings: migrateRecordings(row.recordings),
		rw: rw.slice(0, 3),
		tab,
		theme,
		sprintEndsAt: typeof row.sprintEndsAt === "number" ? row.sprintEndsAt : null
	};
}
function readStorage() {
	if (typeof localStorage === "undefined") return defaults();
	const keys = [
		KEY,
		"eng-academy-v2",
		"eng-academy"
	];
	for (const key of keys) {
		const text = localStorage.getItem(key);
		if (!text) continue;
		try {
			const parsed = sanitize(JSON.parse(text));
			if (parsed) return parsed;
		} catch {}
	}
	return defaults();
}
function pick(state) {
	return {
		xp: state.xp,
		lv: state.lv,
		passed: state.passed,
		days: state.days,
		words: state.words,
		notes: state.notes,
		nid: state.nid,
		teNext: state.teNext,
		teDone: state.teDone,
		discLog: state.discLog,
		listenLog: state.listenLog,
		shadowLog: state.shadowLog,
		recordings: state.recordings,
		rw: state.rw,
		tab: state.tab,
		theme: state.theme,
		sprintEndsAt: state.sprintEndsAt
	};
}
function persist(data) {
	try {
		localStorage.setItem(KEY, JSON.stringify(data));
		localStorage.setItem(THEME_KEY, data.theme);
	} catch {}
}
function logsOf(data, kind) {
	if (kind === "disc") return data.discLog;
	if (kind === "listen") return data.listenLog;
	return data.shadowLog;
}
function withLogs(data, kind, logs) {
	if (kind === "disc") return {
		...data,
		discLog: logs
	};
	if (kind === "listen") return {
		...data,
		listenLog: logs
	};
	return {
		...data,
		shadowLog: logs
	};
}
function capFor(kind, minutes) {
	const raw = Math.ceil(minutes / 10);
	if (kind === "disc") return Math.min(20, raw);
	if (kind === "listen") return Math.min(15, raw);
	return Math.min(10, raw);
}
function syncBonus(day, xp) {
	const required = taskSplit(day.mode).required;
	const ok = !day.rest && required.every((id) => day.done.includes(id));
	if (ok && !day.bonusPaid) return {
		day: {
			...day,
			bonusPaid: true
		},
		xp: xp + 40
	};
	if (!ok && day.bonusPaid) return {
		day: {
			...day,
			bonusPaid: false
		},
		xp: Math.max(0, xp - 40)
	};
	return {
		day,
		xp
	};
}
function isDayFull(day) {
	if (!day) return false;
	if (day.rest || day.legacyOk) return true;
	return taskSplit(day.mode).required.every((id) => day.done.includes(id));
}
function streakCount(days, today = dayKey()) {
	let cursor = today;
	if (!isDayFull(days[cursor])) cursor = shiftBack(cursor);
	let n = 0;
	while (isDayFull(days[cursor])) {
		n += 1;
		cursor = shiftBack(cursor);
		if (n > 4e3) break;
	}
	return n;
}
function shiftBack(key) {
	const [y, m, d] = key.split("-").map(Number);
	const dt = new Date(y, (m ?? 1) - 1, d ?? 1);
	dt.setDate(dt.getDate() - 1);
	return dayKey(dt);
}
function restUsedRecently(days, today) {
	for (let i = 1; i <= 6; i += 1) if (days[shiftBackN(today, i)]?.rest) return true;
	return false;
}
function shiftBackN(today, n) {
	let key = today;
	for (let i = 0; i < n; i += 1) key = shiftBack(key);
	return key;
}
var useAcademy = create((set, get) => ({
	...defaults(),
	hydrated: false,
	notice: "",
	hydrate: () => {
		set({
			...readStorage(),
			hydrated: true,
			notice: ""
		});
	},
	setTab: (tab) => {
		persist({
			...pick(get()),
			tab
		});
		set({ tab });
	},
	setTheme: (theme) => {
		persist({
			...pick(get()),
			theme
		});
		set({ theme });
	},
	setMode: (mode) => {
		get().setDayMode(dayKey(), mode);
	},
	setDayMode: (date, mode) => {
		const state = get();
		let day = {
			...state.days[date] ?? emptyDay(),
			mode
		};
		let xp = state.xp;
		if (date === dayKey()) ({day, xp} = syncBonus(day, xp));
		const days = {
			...state.days,
			[date]: day
		};
		persist({
			...pick(state),
			days,
			xp
		});
		set({
			days,
			xp,
			notice: ""
		});
	},
	toggleRest: () => {
		const today = dayKey();
		const state = get();
		const prev = state.days[today] ?? emptyDay();
		if (!prev.rest && restUsedRecently(state.days, today)) {
			set({ notice: "You already used the one rest day in the last 7 days." });
			return;
		}
		let day = {
			...prev,
			rest: !prev.rest
		};
		let xp = state.xp;
		({day, xp} = syncBonus(day, xp));
		const days = {
			...state.days,
			[today]: day
		};
		persist({
			...pick(state),
			days,
			xp
		});
		set({
			days,
			xp,
			notice: ""
		});
	},
	toggleTask: (id) => {
		const today = dayKey();
		const state = get();
		const prev = state.days[today] ?? emptyDay();
		const wasDone = prev.done.includes(id);
		let done = prev.done;
		let xp = state.xp;
		let teNext = state.teNext;
		let teDone = state.teDone;
		let teCredit = prev.teCredit ?? 0;
		if (wasDone) {
			done = done.filter((item) => item !== id);
			xp = Math.max(0, xp - 10);
			if (id === "te" && teCredit > 0) {
				teNext = Math.max(1, teNext - teCredit);
				teDone = Math.max(0, teDone - teCredit);
				teCredit = 0;
			}
		} else {
			done = [...done, id];
			xp += 10;
			if (id === "te") {
				const batch = lessonsFrom(teNext);
				teCredit = batch.length;
				teNext = Math.min(LESSON_COUNT + 1, teNext + teCredit);
				teDone = Math.min(LESSON_COUNT, teDone + batch.length);
			}
		}
		let day = {
			...prev,
			done,
			teCredit
		};
		({day, xp} = syncBonus(day, xp));
		const days = {
			...state.days,
			[today]: day
		};
		persist({
			...pick(state),
			days,
			xp,
			teNext,
			teDone
		});
		set({
			days,
			xp,
			teNext,
			teDone,
			notice: ""
		});
	},
	setReward: (index, value) => {
		const rw = get().rw.slice();
		rw[index] = value;
		persist({
			...pick(get()),
			rw
		});
		set({ rw });
	},
	addWord: (w, s) => {
		const word = w.trim();
		const sentence = s.trim();
		if (!word || !sentence) {
			set({ notice: "Add the phrase and your own sentence." });
			return false;
		}
		const state = get();
		const words = [...state.words, {
			id: uid(),
			w: word,
			s: sentence,
			d: dayKey()
		}];
		const xp = state.xp + 5;
		persist({
			...pick(state),
			words,
			xp
		});
		set({
			words,
			xp,
			notice: ""
		});
		return true;
	},
	removeWord: (id) => {
		const state = get();
		if (!state.words.some((word) => word.id === id)) return;
		const words = state.words.filter((word) => word.id !== id);
		const xp = Math.max(0, state.xp - 5);
		persist({
			...pick(state),
			words,
			xp
		});
		set({
			words,
			xp
		});
	},
	addNote: () => {
		const state = get();
		const id = Date.now();
		const notes = [...state.notes, {
			id,
			t: "",
			b: ""
		}];
		persist({
			...pick(state),
			notes,
			nid: id
		});
		set({
			notes,
			nid: id
		});
	},
	selectNote: (id) => {
		persist({
			...pick(get()),
			nid: id
		});
		set({ nid: id });
	},
	updateNote: (id, patch) => {
		const notes = get().notes.map((note) => note.id === id ? {
			...note,
			...patch
		} : note);
		persist({
			...pick(get()),
			notes
		});
		set({ notes });
	},
	deleteNote: (id) => {
		const state = get();
		const notes = state.notes.filter((note) => note.id !== id);
		const nid = state.nid === id ? notes[0]?.id ?? 0 : state.nid;
		persist({
			...pick(state),
			notes,
			nid
		});
		set({
			notes,
			nid
		});
	},
	addMinutes: (kind, minutes) => {
		const mins = Math.round(minutes);
		if (!Number.isFinite(mins) || mins <= 0) {
			set({ notice: "Enter the minutes as a number above 0." });
			return;
		}
		const today = dayKey();
		const state = get();
		const logs = [...logsOf(state, kind), {
			d: today,
			m: mins
		}];
		const totalToday = logs.filter((row) => row.d === today).reduce((sum, row) => sum + row.m, 0);
		const prev = state.days[today] ?? emptyDay();
		const already = prev.minuteXp?.[kind] ?? 0;
		const paid = capFor(kind, totalToday);
		const gain = Math.max(0, paid - already);
		let day = {
			...prev,
			minuteXp: {
				...prev.minuteXp,
				[kind]: already + gain
			}
		};
		let xp = state.xp + gain;
		let data = withLogs({
			...pick(state),
			xp
		}, kind, logs);
		data = {
			...data,
			days: {
				...state.days,
				[today]: day
			}
		};
		persist(data);
		set({
			...data,
			notice: ""
		});
	},
	addRecording: (item) => {
		const state = get();
		const recordings = [...state.recordings, item];
		const dropped = recordings.length > 24 ? recordings.splice(0, recordings.length - 24) : [];
		persist({
			...pick(state),
			recordings
		});
		set({ recordings });
		dropped.forEach((old) => {
			deleteClip(old.id);
		});
	},
	removeRecording: (id) => {
		const state = get();
		if (!state.recordings.some((item) => item.id === id)) return;
		const recordings = state.recordings.filter((item) => item.id !== id);
		persist({
			...pick(state),
			recordings
		});
		set({ recordings });
		deleteClip(id);
	},
	minutesThisMonth: (kind, today = dayKey()) => {
		const month = monthKey(today);
		return logsOf(get(), kind).filter((row) => monthKey(row.d) === month).reduce((sum, row) => sum + row.m, 0);
	},
	minutesToday: (kind, today = dayKey()) => logsOf(get(), kind).filter((row) => row.d === today).reduce((sum, row) => sum + row.m, 0),
	setLesson: (n) => {
		const teNext = clampLesson(n);
		const teDone = Math.max(0, Math.min(LESSON_COUNT, teNext - 1));
		persist({
			...pick(get()),
			teNext,
			teDone
		});
		set({
			teNext,
			teDone,
			notice: ""
		});
	},
	placeLevel: (level) => {
		const lv = Math.min(3, Math.max(1, level));
		persist({
			...pick(get()),
			lv
		});
		set({
			lv,
			notice: ""
		});
	},
	passLevel: () => {
		const state = get();
		if (state.lv >= 3) return;
		const passed = state.passed.includes(state.lv) ? state.passed : [...state.passed, state.lv];
		const xp = state.passed.includes(state.lv) ? state.xp : state.xp + 120;
		const lv = state.lv + 1;
		persist({
			...pick(state),
			passed,
			xp,
			lv
		});
		set({
			passed,
			xp,
			lv
		});
	},
	startSprint: () => {
		const sprintEndsAt = Date.now() + 3e5;
		persist({
			...pick(get()),
			sprintEndsAt
		});
		set({ sprintEndsAt });
	},
	clearSprint: () => {
		persist({
			...pick(get()),
			sprintEndsAt: null
		});
		set({ sprintEndsAt: null });
	},
	dismissNotice: () => set({ notice: "" }),
	exportData: () => pick(get()),
	importData: (raw) => {
		const data = sanitize(raw);
		if (!data) {
			set({ notice: "That file is not an English Academy backup." });
			return false;
		}
		persist(data);
		set({
			...data,
			hydrated: true,
			notice: "Backup restored on this device."
		});
		return true;
	}
}));
var token = 0;
var keepAlive = 0;
function englishVoice(voices) {
	return voices.find((v) => /en-US/i.test(v.lang) && /natural|google|samantha|aria|jenny/i.test(v.name)) ?? voices.find((v) => v.lang.toLowerCase().startsWith("en-us")) ?? voices.find((v) => v.lang.toLowerCase().startsWith("en")) ?? null;
}
function canSpeak() {
	return typeof window !== "undefined" && "speechSynthesis" in window;
}
function armKeepAlive() {
	window.clearInterval(keepAlive);
	keepAlive = window.setInterval(() => {
		if (!canSpeak()) return;
		const synth = window.speechSynthesis;
		if (!synth.speaking) {
			window.clearInterval(keepAlive);
			return;
		}
		if (synth.paused) synth.resume();
	}, 8e3);
}
function loadVoices() {
	const synth = window.speechSynthesis;
	const existing = synth.getVoices();
	if (existing.length) return Promise.resolve(existing);
	return new Promise((resolve) => {
		const finish = () => resolve(synth.getVoices());
		synth.addEventListener("voiceschanged", finish, { once: true });
		window.setTimeout(finish, 350);
	});
}
function speak(text, rate = .82) {
	speakLines([text], rate, 0);
}
async function speakLines(lines, rate = .82, gapMs = 220) {
	if (!canSpeak() || lines.length === 0) return false;
	const my = ++token;
	const synth = window.speechSynthesis;
	synth.cancel();
	const voices = await loadVoices();
	if (my !== token) return false;
	const voice = englishVoice(voices);
	let index = 0;
	const next = () => {
		if (my !== token || index >= lines.length) return;
		const utter = new SpeechSynthesisUtterance(lines[index]);
		index += 1;
		utter.lang = "en-US";
		utter.rate = rate;
		if (voice) utter.voice = voice;
		utter.onend = () => {
			if (index >= lines.length || my !== token) return;
			window.setTimeout(next, gapMs);
		};
		synth.speak(utter);
	};
	window.setTimeout(() => {
		if (my !== token) return;
		armKeepAlive();
		next();
	}, 60);
	return true;
}
function cx(...parts) {
	return parts.filter(Boolean).join(" ");
}
var tones = {
	ghost: "border-line bg-card text-ink",
	primary: "border-teal bg-teal text-teal-ink",
	gold: "border-gold bg-gold text-gold-ink",
	ok: "border-ok bg-ok text-ok-ink"
};
function Btn({ tone = "ghost", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cx("inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border px-3.5 text-sm font-semibold", tones[tone], className),
		...props
	});
}
function Card({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cx("rounded-card border border-line bg-card p-4", className),
		children
	});
}
function OutLink({ href, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href,
		target: "_blank",
		rel: "noopener noreferrer",
		className: "inline-flex min-h-11 items-center gap-2 rounded-xl border border-line bg-paper px-3 text-sm font-semibold text-teal",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "min-w-0 text-left",
			children
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {
			className: "size-3.5 shrink-0",
			"aria-hidden": true
		})]
	});
}
function Field(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cx("min-h-11 w-full rounded-xl border border-line bg-paper px-3 text-base text-ink placeholder:text-muted", props.className)
	});
}
function Area(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: cx("w-full rounded-xl border border-line bg-paper px-3 py-2.5 text-base text-ink placeholder:text-muted", props.className)
	});
}
var MAX_MS = 48e4;
function pickMime() {
	if (typeof MediaRecorder === "undefined") return "";
	return [
		"audio/webm;codecs=opus",
		"audio/webm",
		"audio/mp4",
		"audio/aac"
	].find((type) => MediaRecorder.isTypeSupported(type)) ?? "";
}
function clock(totalSeconds) {
	const m = Math.floor(totalSeconds / 60);
	const s = totalSeconds % 60;
	return `${m}:${String(s).padStart(2, "0")}`;
}
function Recorder({ kind, title }) {
	const addRecording = useAcademy((s) => s.addRecording);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [ms, setMs] = (0, import_react.useState)(0);
	const [error, setError] = (0, import_react.useState)("");
	const recRef = (0, import_react.useRef)(null);
	const chunks = (0, import_react.useRef)([]);
	const started = (0, import_react.useRef)(0);
	const timer = (0, import_react.useRef)(0);
	const alive = (0, import_react.useRef)(true);
	(0, import_react.useEffect)(() => {
		alive.current = true;
		return () => {
			alive.current = false;
			window.clearInterval(timer.current);
			const rec = recRef.current;
			if (!rec) return;
			rec.onstop = null;
			rec.stream.getTracks().forEach((track) => track.stop());
			if (rec.state !== "inactive") rec.stop();
		};
	}, []);
	async function start() {
		setError("");
		if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
			setError("This browser cannot record. Use the phone’s voice recorder, then listen there.");
			return;
		}
		try {
			const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
			const mime = pickMime();
			const rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
			chunks.current = [];
			rec.ondataavailable = (event) => {
				if (event.data.size) chunks.current.push(event.data);
			};
			rec.onstop = () => {
				stream.getTracks().forEach((track) => track.stop());
				finish(rec.mimeType || mime || "audio/webm");
			};
			recRef.current = rec;
			started.current = Date.now();
			setMs(0);
			setPhase("rec");
			rec.start();
			timer.current = window.setInterval(() => {
				const elapsed = Date.now() - started.current;
				setMs(elapsed);
				if (elapsed >= MAX_MS && rec.state !== "inactive") rec.stop();
			}, 250);
		} catch {
			setError("Mic is blocked. Allow the microphone, or record in the phone voice app.");
		}
	}
	async function finish(mime) {
		window.clearInterval(timer.current);
		const blob = new Blob(chunks.current, { type: mime });
		const seconds = Math.max(1, Math.round((Date.now() - started.current) / 1e3));
		if (!alive.current) return;
		if (blob.size < 800) {
			setPhase("idle");
			setError("That was too short to keep.");
			return;
		}
		setPhase("save");
		const id = typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
		try {
			await saveClip(id, blob);
			if (!alive.current) {
				await deleteClip(id);
				return;
			}
			addRecording({
				id,
				d: dayKey(),
				kind,
				title,
				seconds
			});
			setPhase("idle");
			setMs(0);
		} catch {
			await deleteClip(id).catch(() => void 0);
			if (!alive.current) return;
			setPhase("idle");
			setError("Could not save that recording on this device.");
		}
	}
	function stop() {
		const rec = recRef.current;
		if (rec && rec.state !== "inactive") rec.stop();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-2",
		children: [phase === "rec" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			tone: "gold",
			onClick: stop,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, {
					className: "size-4",
					"aria-hidden": true
				}),
				"Stop · ",
				clock(Math.floor(ms / 1e3))
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			tone: "primary",
			onClick: start,
			disabled: phase === "save",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {
				className: "size-4",
				"aria-hidden": true
			}), phase === "save" ? "Saving" : "Record"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-muted",
			children: title
		})]
	}), error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-sm font-semibold text-warn",
		children: error
	})] });
}
var KIND_NAME = {
	news: "Article",
	twister: "Twister",
	call: "Call",
	speak: "Speaking"
};
function RecordingList({ items, empty }) {
	const removeRecording = useAcademy((s) => s.removeRecording);
	if (items.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-sm text-muted",
		children: empty
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2",
		children: [...items].reverse().map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipRow, {
			item,
			onRemove: () => removeRecording(item.id)
		}, item.id))
	});
}
function ClipRow({ item, onRemove }) {
	const [url, setUrl] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		return () => {
			if (url) URL.revokeObjectURL(url);
		};
	}, [url]);
	async function toggle() {
		if (url) {
			URL.revokeObjectURL(url);
			setUrl(null);
			return;
		}
		try {
			const blob = await loadClip(item.id);
			if (!blob) {
				setError("That file is no longer on this device.");
				return;
			}
			setError("");
			setUrl(URL.createObjectURL(blob));
		} catch {
			setError("Could not play that recording.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "border-b border-line py-3 last:border-b-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: item.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							KIND_NAME[item.kind],
							" · ",
							item.d,
							" · ",
							clock(item.seconds)
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: toggle,
						children: url ? "Hide" : "Play"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: onRemove,
						children: "Remove"
					})]
				})]
			}),
			url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
				className: "mt-2 w-full",
				controls: true,
				autoPlay: true,
				src: url
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm font-semibold text-warn",
				children: error
			})
		]
	});
}
function LabView() {
	const [index, setIndex] = (0, import_react.useState)(0);
	const current = ALL_TWISTERS[index] ?? ALL_TWISTERS[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-wide text-teal uppercase",
					children: "On the commute"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-xl font-extrabold tracking-tight",
					children: current.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: current.why
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 space-y-2",
					children: current.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-semibold leading-snug",
						children: line
					}, line))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							tone: "primary",
							onClick: () => speakLines(current.lines, .82),
							children: "Hear it"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => speakLines(current.lines, .55),
							children: "Slow"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => speakLines(current.lines, .7, 700),
							children: "Line by line"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Recorder, {
						kind: "twister",
						title: current.label
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Hear it. Repeat slowly three times. Then normal speed. Record yourself. Listen back. Do not rush a dirty sound."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						className: "flex-1",
						onClick: () => setIndex((value) => (value - 1 + ALL_TWISTERS.length) % ALL_TWISTERS.length),
						children: "Previous"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						tone: "gold",
						className: "flex-1",
						onClick: () => setIndex((value) => (value + 1) % ALL_TWISTERS.length),
						children: "Next"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-center text-xs text-muted",
					children: [
						index + 1,
						" / ",
						ALL_TWISTERS.length,
						" · engVid 1, 2, 3, 21, 22, then your two starters"
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "rounded-card border border-line bg-card px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer text-base font-bold",
					children: "All seven, written out"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-col gap-4",
					children: ALL_TWISTERS.map((twister) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-bold",
							children: twister.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: twister.why
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 space-y-1 text-sm",
							children: twister.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: line }, line))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								onClick: () => speakLines(twister.lines, .82),
								children: "Hear it"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								onClick: () => speakLines(twister.lines, .55),
								children: "Slow"
							})]
						})
					] }, twister.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-bold",
				children: "Sounds to fix first"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "th, s/z, and b/p. Tap a word, copy it, then say the pair back to back."
			})] }),
			SOUNDS.map((sound) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold",
					children: sound.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: sound.how
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: sound.words.map((word) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => speak(word, .75),
						children: word
					}, word))
				})
			] }, sound.title)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "Source for 1, 2, 3, 21 and 22: engVid, 50 Tongue Twisters to improve pronunciation in English. The two starters are yours."
			})
		]
	});
}
function HomeView({ today }) {
	const lv = useAcademy((s) => s.lv);
	const days = useAcademy((s) => s.days);
	const setTab = useAcademy((s) => s.setTab);
	const teNext = useAcademy((s) => s.teNext);
	const day = days[today];
	const mode = day?.mode ?? "n";
	const required = orderedTasks(mode).filter((item) => !item.optional);
	const done = required.filter((item) => day?.done.includes(item.id)).length;
	const pct = required.length ? Math.round(done / required.length * 100) : 0;
	const next = required.find((item) => !day?.done.includes(item.id));
	const nextTitle = next ? taskCopy(next.id, mode, teNext).title : "Core is done";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-extrabold tracking-tight",
					children: "Welcome back, Ahmed"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"Level ",
						lv,
						" · ",
						streakCount(days, today),
						" day streak · today ",
						done,
						"/",
						required.length
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-2.5 overflow-hidden rounded-full bg-line",
					role: "progressbar",
					"aria-valuenow": pct,
					"aria-valuemin": 0,
					"aria-valuemax": 100,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-ok",
						style: { width: `${pct}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm font-semibold",
					children: ["Next: ", nextTitle]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							tone: "primary",
							onClick: () => setTab("today"),
							children: "Open today"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => setTab("lab"),
							children: "Sound Lab"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => setTab("words"),
							children: "Words"
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-bold",
				children: "Rules that do not move"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-2 space-y-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "No Arabic subtitles in games, shows, anime, or animation." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Read aloud. If the task says record, record on your phone." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Discord is talking. Silent scrolling does not count. Minimum 30 minutes, last thing." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Grammar is for a mistake you already made. It is not the main study." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A short day beats a skipped day. Use Recovery when the shift empties you." })
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold",
					children: "How you actually learn"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm",
					children: "Hear it, copy it, use it, notice the mistake, repeat. Friends, English-dubbed anime, American animation, and games with the subtitles off already taught you more than rule lists. This plan starts there again, in a size that fits rotating shifts."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "The level here is a training level, not a certificate. The job stays until the English option is real. Travel English is the same muscle."
				})
			] })
		]
	});
}
function PlanView() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-bold",
				children: "What this is"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm",
				children: "A speaking plan, built for exposure and imitation. Not a grammar course. You already know you do not learn by memorising rules. Whole sentences, from TalkEnglish, stories, shows, and real talk."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-bold",
				children: "The real week"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-2 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: "Work days"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "1–2 hours. Shifts rotate. The commute is for tongue twisters, not new lessons."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: "Days off"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Two days, and they move every week or two. Use them for the full 3–4 hour stack."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: "The job"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Arabic call centre. Do not quit before an English option is actually ready."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: "After graduation"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "English stays in your pocket for work and for travel. Same daily speaking, not a second hobby plan."
						})]
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-bold",
				children: "The day, in this order"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-2 list-decimal space-y-2 pl-5 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Morning: say yesterday’s words and your sentences." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "TalkEnglish: 3 Speaking Basics lessons, in order. Listen, repeat, say them without looking." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "News in Levels, Level 2: 3 articles. Open on the computer. Record on the phone." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Write one sentence for each phrase you keep." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "On the way: engVid tongue twisters 1, 2, 3, 21, 22. Let the app or a video say them. Copy the sound." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "My Story Animated: 60 minutes, split on work days. Imitate how they speak. No Arabic." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Five minutes of shadowing. Friends, English-dubbed anime, animation, or your playlist." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "If you play: Arabic subtitles off." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Last: at least 30 minutes on Discord with foreigners. No script." })
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold",
					children: "Three sizes"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Recovery, 50–60 min." }), " Review, 3 TalkEnglish lessons, tongue twisters, 30 minutes on Discord. That is still a real English day."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Normal, 1–2 h." }), " Add the three articles, your sentences, a 5-minute shadow, and My Story Animated in blocks."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Day off, 3–4 h." }), " The full hour of My Story Animated, a customer-call recording, games with subtitles off, then Discord."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "One rest day every 7 days protects the streak. Starting is the hard part, so the 5-minute button exists. Five minutes is a start, not the goal. Mark the moving offs on Today, under Next 7 days."
				})
			] })
		]
	});
}
function LevelsView() {
	const lv = useAcademy((s) => s.lv);
	const passLevel = useAcademy((s) => s.passLevel);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [LEVELS.map((level, index) => {
			const n = index + 1;
			const state = lv === n ? "Now" : lv > n ? "Passed" : "Later";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: cx("border-l-4", lv === n ? "border-l-gold" : lv > n ? "border-l-ok" : "border-l-line"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold text-muted",
						children: state
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-lg font-extrabold",
						children: [
							"Level ",
							n,
							": ",
							level.name
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: level.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-bold",
							children: "Graduation test. "
						}), level.test]
					}),
					lv === n && n < 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						tone: "gold",
						className: "mt-3",
						onClick: passLevel,
						children: "I passed this test"
					}),
					lv > n && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm font-bold text-ok",
						children: "Passed"
					})
				]
			}, level.name);
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Move up because the recording got better, not because a date arrived. Listen back before you press the button. This app cannot hear you."
		})]
	});
}
function ResourcesView() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-base font-bold",
			children: "Open the source, do the task, close it"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Do not turn this list into a collection. The path is already fixed on Today."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "p-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: RESOURCES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "border-b border-line px-4 py-3 last:border-b-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: item.href,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "block font-semibold text-teal",
					children: item.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: item.detail
				})]
			}, item.href)) })
		})]
	});
}
function CheckView() {
	const lv = useAcademy((s) => s.lv);
	const placeLevel = useAcademy((s) => s.placeLevel);
	const [flags, setFlags] = (0, import_react.useState)(() => CHECKS.map(() => false));
	const [msg, setMsg] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-base font-bold",
			children: "Honest level check"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-muted",
			children: [
				"Tick only what you can do today, without rehearsing it first. This picks a training level. It is not a certificate. You are on level ",
				lv,
				" now."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2",
			children: CHECKS.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex cursor-pointer gap-3 border-b border-line py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "mt-0.5 size-6 accent-ok",
					checked: flags[index],
					onChange: (event) => setFlags((prev) => prev.map((value, i) => i === index ? event.target.checked : value))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm",
					children: item
				})]
			}) }, item))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			tone: "gold",
			className: "mt-3",
			onClick: () => {
				const n = flags.filter(Boolean).length;
				const level = n <= 1 ? 1 : n <= 3 ? 2 : 3;
				placeLevel(level);
				setMsg(`Start at training level ${level}. Move up only after the performance test.`);
			},
			children: "Set training level"
		}),
		msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 font-bold text-ok",
			children: msg
		})
	] });
}
function WordsView({ today }) {
	const words = useAcademy((s) => s.words);
	const addWord = useAcademy((s) => s.addWord);
	const removeWord = useAcademy((s) => s.removeWord);
	const [w, setW] = (0, import_react.useState)("");
	const [s, setS] = (0, import_react.useState)("");
	const yesterday = shiftKey(today, -1);
	const yWords = words.filter((word) => word.d === yesterday);
	const recent = [...words].reverse().slice(0, 40);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold",
					children: "Add a phrase"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-3 flex flex-col gap-2",
					onSubmit: (event) => {
						event.preventDefault();
						if (addWord(w, s)) {
							setW("");
							setS("");
						}
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							value: w,
							onChange: (event) => setW(event.target.value),
							placeholder: "Word or phrase",
							"aria-label": "Word or phrase"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
							value: s,
							onChange: (event) => setS(event.target.value),
							rows: 3,
							placeholder: "Your own sentence",
							"aria-label": "Your sentence"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "submit",
							tone: "gold",
							children: "Save"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Prefer phrases from News in Levels, a story, a game, or a conversation. Not a random word list."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WordList, {
				title: "Yesterday — say these",
				items: yWords,
				onRemove: removeWord,
				empty: "No phrases saved yesterday.",
				speakable: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WordList, {
				title: "Recent",
				items: recent,
				onRemove: removeWord,
				empty: "Your journal is empty."
			})
		]
	});
}
function WordList({ title, items, empty, speakable, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "text-base font-bold",
		children: title
	}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-sm text-muted",
		children: empty
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "border-b border-line py-3 last:border-b-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: item.w
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: item.s
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-sm font-semibold text-muted",
					onClick: () => onRemove(item.id),
					children: "Remove"
				})]
			}), speakable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: () => speak(`${item.w}. ${item.s}`, .86),
					children: "Hear it"
				})
			})]
		}, item.id))
	})] });
}
function NotesView() {
	const notes = useAcademy((s) => s.notes);
	const nid = useAcademy((s) => s.nid);
	const addNote = useAcademy((s) => s.addNote);
	const selectNote = useAcademy((s) => s.selectNote);
	const updateNote = useAcademy((s) => s.updateNote);
	const deleteNote = useAcademy((s) => s.deleteNote);
	const [armed, setArmed] = (0, import_react.useState)(null);
	const current = notes.find((note) => note.id === nid) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 flex flex-wrap gap-2",
		children: [notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => selectNote(note.id),
			className: cx("min-h-11 rounded-xl border px-3 text-sm font-semibold", note.id === nid ? "border-teal bg-teal text-teal-ink" : "border-line bg-card"),
			children: note.t.trim() || "Untitled"
		}, note.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			tone: "gold",
			onClick: addNote,
			children: "New page"
		})]
	}), current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			value: current.t,
			"aria-label": "Page title",
			placeholder: "Page title",
			onChange: (event) => updateNote(current.id, { t: event.target.value }),
			className: "font-bold"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
			value: current.b,
			"aria-label": "Page body",
			rows: 14,
			placeholder: "Shift pattern, a mistake to fix, a phrase, a weekly note…",
			className: "mt-2",
			onChange: (event) => updateNote(current.id, { b: event.target.value })
		}),
		armed === current.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				tone: "gold",
				onClick: () => {
					deleteNote(current.id);
					setArmed(null);
				},
				children: "Delete this page"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				onClick: () => setArmed(null),
				children: "Keep it"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			className: "mt-3",
			onClick: () => setArmed(current.id),
			children: "Delete page"
		})
	] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Pages for your shift pattern, sounds that broke, useful phrases, and a monthly listen-back. Saved on this device."
	}) })] });
}
function ProgressView({ today }) {
	const days = useAcademy((s) => s.days);
	const words = useAcademy((s) => s.words);
	const teNext = useAcademy((s) => s.teNext);
	const teDone = useAcademy((s) => s.teDone);
	const xp = useAcademy((s) => s.xp);
	const setLesson = useAcademy((s) => s.setLesson);
	const exportData = useAcademy((s) => s.exportData);
	const importData = useAcademy((s) => s.importData);
	const discLog = useAcademy((s) => s.discLog);
	const listenLog = useAcademy((s) => s.listenLog);
	const shadowLog = useAcademy((s) => s.shadowLog);
	const recordings = useAcademy((s) => s.recordings);
	const fileRef = (0, import_react.useRef)(null);
	const [lessonDraft, setLessonDraft] = (0, import_react.useState)(String(Math.min(teNext, LESSON_COUNT + 1)));
	const keys = Array.from({ length: 30 }, (_, i) => shiftKey(today, -29 + i));
	const doneDays = keys.filter((key) => isDayFull(days[key])).length;
	const month = monthKey(today);
	const sumMonth = (rows) => rows.filter((row) => monthKey(row.d) === month).reduce((total, row) => total + row.m, 0);
	const disc = sumMonth(discLog);
	const listen = sumMonth(listenLog);
	const shadow = sumMonth(shadowLog);
	const upcoming = lessonsFrom(teNext);
	const position = Math.min(LESSON_COUNT, Math.max(0, teNext - 1));
	const pct = Math.round(position / LESSON_COUNT * 100);
	const rank = rankFor(xp);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold",
					children: "Last 30 days"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-3xl font-extrabold tabular-nums",
					children: [doneDays, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-base font-semibold text-muted",
						children: " / 30 done"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-7 gap-1.5",
					children: keys.map((key) => {
						const row = days[key];
						const on = isDayFull(row);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							title: key,
							className: cx("h-8 rounded-md", row?.rest ? "bg-gold" : on ? "bg-ok" : "bg-line")
						}, key);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: "Gold is a rest day. Green is a finished core."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold",
					children: "TalkEnglish Speaking Basics"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						position,
						" of ",
						LESSON_COUNT,
						" finished · ",
						LESSON_COUNT - position,
						" left",
						teDone !== position ? ` · checks recorded ${teDone}` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-2.5 overflow-hidden rounded-full bg-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-teal",
						style: { width: `${pct}%` }
					})
				}),
				upcoming.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: upcoming.map((lesson) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(OutLink, {
						href: lessonHref(lesson.alid),
						children: [
							lesson.n,
							". ",
							lesson.title
						]
					}) }, lesson.alid))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm font-semibold text-ok",
					children: "Basics are finished. Move to Regular English, 3 lessons a day, same method."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-3 flex flex-wrap gap-2",
					onSubmit: (event) => {
						event.preventDefault();
						setLesson(Number(lessonDraft));
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						type: "number",
						min: 1,
						max: LESSON_COUNT + 1,
						inputMode: "numeric",
						"aria-label": "Next lesson number",
						value: lessonDraft,
						onChange: (event) => setLessonDraft(event.target.value),
						className: "w-32"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: "Set next lesson"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs text-muted",
					children: [
						"Use ",
						LESSON_COUNT + 1,
						" when Basics are finished. The site sometimes says 90 lessons. The live list has ",
						LESSON_COUNT,
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs text-muted",
					children: ["Rank ", rank.current.name]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-bold",
				children: "Word journal"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-3xl font-extrabold tabular-nums",
				children: words.length
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold",
					children: "This month"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Discord" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
								className: "tabular-nums",
								children: [disc, " min"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Listening" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
								className: "tabular-nums",
								children: [listen, " min"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Shadowing" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
								className: "tabular-nums",
								children: [shadow, " min"]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Add minutes on Today, right after the block. Listening target: 60 minutes of My Story Animated on a full day, 20 on a light day, split around the shift."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold",
					children: "Recordings"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Listen back here. Compare one from about a month ago with one from today. Audio stays in this browser and is not inside the backup file."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecordingList, {
					items: recordings,
					empty: "No recordings yet. Use Record on Today or Sounds."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-bold",
				children: "Monthly listen-back"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "On a day off, play a recording from about a month ago next to one from today. Listen for th, s/z, pace, pauses, and filler. Judge the recording, not your mood. If two months show no change, change the method."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold",
					children: "Backup on this phone"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "The plan stays on this device. Export a file before you clear the browser, or when you change phones."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							tone: "primary",
							onClick: () => {
								const blob = new Blob([JSON.stringify(exportData(), null, 2)], { type: "application/json" });
								const url = URL.createObjectURL(blob);
								const link = document.createElement("a");
								link.href = url;
								link.download = `english-academy-${today}.json`;
								link.click();
								URL.revokeObjectURL(url);
							},
							children: "Download backup"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => fileRef.current?.click(),
							children: "Restore backup"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "application/json,.json",
							className: "sr-only",
							onChange: async (event) => {
								const file = event.target.files?.[0];
								event.target.value = "";
								if (!file) return;
								try {
									importData(JSON.parse(await file.text()));
								} catch {
									useAcademy.setState({ notice: "That file could not be read." });
								}
							}
						})
					]
				})
			] })
		]
	});
}
function useNow(active) {
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		if (!active) return;
		const id = window.setInterval(() => setNow(Date.now()), 250);
		return () => window.clearInterval(id);
	}, [active]);
	return now;
}
function TodayView({ today }) {
	const days = useAcademy((s) => s.days);
	const words = useAcademy((s) => s.words);
	const teNext = useAcademy((s) => s.teNext);
	const rw = useAcademy((s) => s.rw);
	const sprintEndsAt = useAcademy((s) => s.sprintEndsAt);
	const setMode = useAcademy((s) => s.setMode);
	const toggleRest = useAcademy((s) => s.toggleRest);
	const toggleTask = useAcademy((s) => s.toggleTask);
	const setReward = useAcademy((s) => s.setReward);
	const startSprint = useAcademy((s) => s.startSprint);
	const clearSprint = useAcademy((s) => s.clearSprint);
	const addMinutes = useAcademy((s) => s.addMinutes);
	const setDayMode = useAcademy((s) => s.setDayMode);
	const recordings = useAcademy((s) => s.recordings);
	const setTab = useAcademy((s) => s.setTab);
	const [recKind, setRecKind] = (0, import_react.useState)("news");
	const day = days[today] ?? {
		mode: "n",
		done: [],
		rest: false
	};
	const meta = modeMeta(day.mode);
	const items = orderedTasks(day.mode);
	const required = taskSplit(day.mode).required;
	const doneRequired = required.filter((id) => day.done.includes(id)).length;
	const pct = required.length ? Math.round(doneRequired / required.length * 100) : 0;
	const nextId = required.find((id) => !day.done.includes(id));
	const streak = streakCount(days, today);
	const yesterday = shiftKey(today, -1);
	const yWords = words.filter((word) => word.d === yesterday);
	const now = useNow(Boolean(sprintEndsAt));
	const left = sprintEndsAt ? sprintEndsAt - now : null;
	const running = left !== null && left > 0;
	const justDone = left !== null && left <= 0 && now - (sprintEndsAt ?? 0) < 12e4;
	(0, import_react.useEffect)(() => {
		if (sprintEndsAt && Date.now() - sprintEndsAt > 12e4) clearSprint();
	}, [
		sprintEndsAt,
		now,
		clearSprint
	]);
	let headline = "Start with 5 minutes. Then do the next task on the list.";
	if (day.rest) headline = "Rest day. Your streak stays. Come back tomorrow.";
	else if (!nextId) headline = "Core is done for today. Stop, or keep the optional exposure.";
	else if (pct >= 50) headline = "Past halfway. Finish the next small task, not the whole day at once.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: MODES.map((mode) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setMode(mode.id),
					className: cx("min-h-16 rounded-2xl border px-2 py-2 text-center", day.mode === mode.id ? "border-ok bg-ok text-ok-ink" : "border-line bg-card text-ink"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-bold",
						children: mode.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cx("block text-xs", day.mode === mode.id ? "text-ok-ink/80" : "text-muted"),
						children: mode.time
					})]
				}, mode.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeekPlan, {
				today,
				days,
				onSet: setDayMode
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-base font-bold text-ok",
					children: headline
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: meta.line
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-7 gap-1.5",
					children: Array.from({ length: 7 }, (_, i) => {
						const key = shiftKey(today, -6 + i);
						const row = days[key];
						const full = isDayFull(row);
						const rest = Boolean(row?.rest);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center text-xs text-muted",
							children: [weekdayShort(key), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cx("mt-1 block h-5 rounded-md", rest ? "bg-gold" : full ? "bg-ok" : "bg-line") })]
						}, key);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
						tone: "gold",
						onClick: startSprint,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, {
							className: "size-4",
							"aria-hidden": true
						}), "5-minute start"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: toggleRest,
						children: day.rest ? "Cancel rest day" : "Use one rest day"
					})]
				}),
				running && left !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-center text-4xl font-extrabold tabular-nums tracking-tight",
					children: formatLeft(left)
				}),
				justDone && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						children: "Five minutes done. Keep going, or stop honestly."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: clearSprint,
						children: "Clear"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: [
						"Streak ",
						streak,
						" · core ",
						doneRequired,
						"/",
						required.length,
						teNext > LESSON_COUNT ? " · Speaking Basics finished" : ` · next lesson ${teNext}`
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-b border-line px-4 py-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-bold",
						children: "Today, in order"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, {
					id: item.id,
					optional: item.optional,
					active: item.id === nextId,
					checked: day.done.includes(item.id),
					mode: day.mode,
					teNext,
					reviewWords: item.id === "review" ? yWords : void 0,
					onToggle: () => toggleTask(item.id),
					onWords: () => setTab("words"),
					onLab: () => setTab("lab")
				}, item.id)) })]
			}),
			items.some((item) => item.id === "mock") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold",
					children: "Customer call — late order"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "They are upset. The order is three days late. You cannot refund it. You can send a new one today. Do not read this while you record. Use it once, then close it."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-3 list-decimal space-y-1 pl-5 text-sm",
					children: CALL_STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: step }, step))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => speakLines(CALL_MODEL, .86),
						className: "w-full sm:w-auto",
						children: "Hear a simple model"
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogCard, {
				today,
				mode: day.mode,
				addMinutes
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold",
					children: "Record, then listen back"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Read the article on the computer. Record here on the phone. Same for the customer call. These stay in this browser. They are not inside the backup file."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						["news", "Article"],
						["call", "Call"],
						["speak", "Speaking"]
					].map(([kind, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setRecKind(kind),
						className: cx("min-h-11 rounded-xl border px-3 text-sm font-semibold", recKind === kind ? "border-teal bg-teal text-teal-ink" : "border-line bg-card"),
						children: label
					}, kind))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Recorder, {
						kind: recKind,
						title: REC_TITLE[recKind]
					}, recKind)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecordingList, {
					items: recordings.filter((item) => item.d === today),
					empty: "Nothing recorded today yet."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-bold",
				children: "Rewards you picked"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-col gap-2",
				children: [
					["Half the core", pct >= 50],
					["Full core", pct === 100],
					["7-day streak", streak >= 7]
				].map(([label, on], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: cx("mb-1 block text-xs font-semibold", on ? "text-ok" : "text-muted"),
						children: [label, on ? " — unlocked" : ""]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						value: rw[index] ?? "",
						"aria-label": `${label} reward`,
						onChange: (event) => setReward(index, event.target.value),
						className: on ? "border-ok" : void 0
					})]
				}, String(label)))
			})] })
		]
	});
}
function TaskRow({ id, optional, active, checked, mode, teNext, reviewWords, onToggle, onWords, onLab }) {
	const copy = taskCopy(id, mode, teNext);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: cx("border-b border-line px-4 py-3 last:border-b-0", active && "bg-teal-soft/60"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex cursor-pointer gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked,
					onChange: onToggle,
					className: "mt-0.5 size-6 shrink-0 accent-ok"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cx("block font-semibold", checked && "text-muted line-through"),
							children: copy.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-0.5 block text-sm text-muted no-underline",
							children: [copy.detail, reviewWords ? reviewWords.length ? ` ${reviewWords.length} saved from yesterday.` : " Nothing saved yesterday. Say three older phrases if you have them." : ""]
						}),
						optional && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 inline-block rounded-full bg-line px-2 py-0.5 text-xs font-semibold text-muted",
							children: "Optional"
						}),
						active && !checked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 ml-1 inline-block rounded-full bg-teal px-2 py-0.5 text-xs font-semibold text-teal-ink",
							children: "Next"
						})
					]
				})]
			}),
			reviewWords && reviewWords.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 space-y-3 pl-9",
				children: reviewWords.map((word) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						children: word.w
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: word.s
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						className: "mt-1",
						onClick: () => speak(`${word.w}. ${word.s}`, .86),
						children: "Hear it"
					})
				] }, word.id))
			}),
			copy.links.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex flex-col gap-2 pl-9",
				children: copy.links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutLink, {
					href: link.href,
					children: link.label
				}, link.href + link.label))
			}),
			id === "review" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 pl-9",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: onWords,
					children: "Open words"
				})
			}),
			id === "tw" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 pl-9",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: onLab,
					children: "Open Sound Lab"
				})
			}),
			id === "vocab" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 pl-9",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: onWords,
					children: "Write sentences"
				})
			})
		]
	});
}
function LogCard({ today, mode, addMinutes }) {
	const disc = useAcademy((s) => s.discLog);
	const listen = useAcademy((s) => s.listenLog);
	const shadow = useAcademy((s) => s.shadowLog);
	const sum = (rows) => rows.filter((row) => row.d === today).reduce((total, row) => total + row.m, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-base font-bold",
			children: "Log real minutes"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Speaking, listening, or shadowing. Not scrolling."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MinuteRow, {
					label: "Discord",
					value: sum(disc),
					target: 30,
					onAdd: (n) => addMinutes("disc", n)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MinuteRow, {
					label: "My Story Animated",
					value: sum(listen),
					target: mode === "s" ? 20 : 60,
					onAdd: (n) => addMinutes("listen", n)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MinuteRow, {
					label: "Shadowing",
					value: sum(shadow),
					target: 5,
					onAdd: (n) => addMinutes("shadow", n)
				})
			]
		})
	] });
}
function MinuteRow({ label, value, target, onAdd }) {
	const [draft, setDraft] = (0, import_react.useState)("");
	const pct = Math.max(0, Math.min(100, Math.round(value / target * 100)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "flex flex-wrap items-center gap-2",
		onSubmit: (event) => {
			event.preventDefault();
			onAdd(Number(draft));
			setDraft("");
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-36 text-sm font-semibold",
				children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "ml-2 font-bold tabular-nums text-teal",
					children: [
						value,
						"/",
						target,
						" min"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				type: "number",
				min: 1,
				inputMode: "numeric",
				placeholder: "Minutes",
				"aria-label": `${label} minutes`,
				value: draft,
				onChange: (event) => setDraft(event.target.value),
				className: "w-28 flex-1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				type: "submit",
				tone: "primary",
				children: "Add"
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-1.5 h-1.5 overflow-hidden rounded-full bg-line",
		role: "progressbar",
		"aria-valuenow": pct,
		"aria-valuemin": 0,
		"aria-valuemax": 100,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full bg-ok",
			style: { width: `${pct}%` }
		})
	})] });
}
function formatLeft(ms) {
	const total = Math.ceil(ms / 1e3);
	const m = Math.floor(total / 60);
	const s = total % 60;
	return `${m}:${String(s).padStart(2, "0")}`;
}
var REC_TITLE = {
	news: "News in Levels reading",
	call: "Customer call",
	speak: "Unscripted speaking",
	twister: "Tongue twister"
};
var MODE_SHORT = {
	n: "Work",
	o: "Off",
	s: "Light"
};
function cycleMode(mode) {
	if (mode === "n") return "o";
	if (mode === "o") return "s";
	return "n";
}
function WeekPlan({ today, days, onSet }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-base font-bold",
			children: "Next 7 days"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Off days move. Tap a day: Work, then Off, then Light."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid grid-cols-7 gap-1",
			children: Array.from({ length: 7 }, (_, i) => {
				const key = shiftKey(today, i);
				const mode = days[key]?.mode ?? "n";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-label": `${weekdayShort(key)} ${MODE_SHORT[mode]}`,
					onClick: () => onSet(key, cycleMode(mode)),
					className: cx("min-h-16 rounded-xl border px-0.5 py-1.5 text-center", i === 0 ? "border-2 border-teal" : "border", mode === "o" && "bg-ok-soft", mode === "s" && "bg-gold-soft", mode === "n" && "bg-card", i !== 0 && mode === "o" && "border-ok", i !== 0 && mode === "s" && "border-gold", i !== 0 && mode === "n" && "border-line"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted",
							children: i === 0 ? "Today" : weekdayShort(key)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-bold tabular-nums",
							children: Number(key.slice(8))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs font-semibold",
							children: MODE_SHORT[mode]
						})
					]
				}, key);
			})
		})
	] });
}
var NAV = [
	{
		id: "today",
		label: "Today",
		icon: ListChecks,
		primary: true
	},
	{
		id: "lab",
		label: "Sounds",
		icon: AudioLines,
		primary: true
	},
	{
		id: "words",
		label: "Words",
		icon: Library,
		primary: true
	},
	{
		id: "progress",
		label: "Progress",
		icon: ChartNoAxesColumn,
		primary: true
	},
	{
		id: "home",
		label: "Home",
		icon: House
	},
	{
		id: "plan",
		label: "My plan",
		icon: Route
	},
	{
		id: "levels",
		label: "Levels",
		icon: Flag
	},
	{
		id: "resources",
		label: "Resources",
		icon: BookOpen
	},
	{
		id: "notes",
		label: "Notes",
		icon: NotebookPen
	},
	{
		id: "check",
		label: "Level check",
		icon: Compass
	}
];
function Academy() {
	const tab = useAcademy((s) => s.tab);
	const setTab = useAcademy((s) => s.setTab);
	const xp = useAcademy((s) => s.xp);
	const lv = useAcademy((s) => s.lv);
	const teDone = useAcademy((s) => s.teDone);
	const days = useAcademy((s) => s.days);
	const theme = useAcademy((s) => s.theme);
	const setTheme = useAcademy((s) => s.setTheme);
	const notice = useAcademy((s) => s.notice);
	const dismissNotice = useAcademy((s) => s.dismissNotice);
	const [today, setToday] = (0, import_react.useState)(dayKey);
	const [more, setMore] = (0, import_react.useState)(false);
	const [dark, setDark] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setToday(dayKey()), 3e4);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(prefers-color-scheme: dark)");
		const apply = () => {
			const isDark = theme === "dark" || theme === "system" && mq.matches;
			document.documentElement.dataset.theme = isDark ? "dark" : "light";
			setDark(isDark);
		};
		apply();
		mq.addEventListener("change", apply);
		return () => mq.removeEventListener("change", apply);
	}, [theme]);
	const rank = rankFor(xp);
	const streak = streakCount(days, today);
	const lessons = Math.min(LESSON_COUNT, teDone);
	function open(next) {
		setTab(next);
		setMore(false);
		window.scrollTo(0, 0);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad mx-auto min-h-screen w-full max-w-5xl px-4 pt-5 md:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-teal",
							children: "Speaking practice for shift days"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-3xl font-extrabold tracking-tight",
							children: "English Academy"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": dark ? "Switch to light" : "Switch to dark",
							onClick: () => setTheme(nextTheme(theme, dark)),
							className: "inline-flex size-11 items-center justify-center rounded-xl border border-line bg-card",
							children: dark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-5" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 rounded-card bg-teal px-4 py-4 text-teal-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-end justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-2xl font-extrabold",
									children: rank.current.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-teal-ink/80",
									children: rank.next ? `${rank.next.xp - xp} XP to ${rank.next.name}` : "Top rank"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-semibold",
									children: ["Level ", lv]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-2.5 overflow-hidden rounded-full bg-teal-ink/25",
								role: "progressbar",
								"aria-label": "Rank progress",
								"aria-valuenow": Math.round(rank.pct),
								"aria-valuemin": 0,
								"aria-valuemax": 100,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-gold",
									style: { width: `${rank.pct}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-teal-ink/90",
								children: "English for a better job, without quitting early. Travel uses the same plan."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-4 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								value: String(streak),
								label: "streak"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								value: String(lv),
								label: "level"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								value: String(xp),
								label: "XP"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								value: String(lessons),
								label: "lessons"
							})
						]
					})
				]
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-start justify-between gap-3 rounded-2xl border border-warn bg-warn-soft px-3 py-3 text-sm text-warn",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: notice }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "font-semibold",
					onClick: dismissNotice,
					children: "Close"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:grid md:grid-cols-[13.5rem_minmax(0,1fr)] md:items-start md:gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mb-3 hidden md:sticky md:top-4 md:block",
					"aria-label": "Sections",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-col gap-1",
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							item,
							active: tab === item.id,
							onClick: () => open(item.id)
						}, item.id))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "min-w-0",
					children: [
						tab === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, { today }),
						tab === "today" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodayView, { today }),
						tab === "plan" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanView, {}),
						tab === "levels" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelsView, {}),
						tab === "lab" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabView, {}),
						tab === "words" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WordsView, { today }),
						tab === "resources" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResourcesView, {}),
						tab === "notes" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesView, {}),
						tab === "progress" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressView, { today }),
						tab === "check" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckView, {})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "safe-dock fixed inset-x-0 bottom-0 z-30 border-t border-line bg-card md:hidden",
				"aria-label": "Primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-5xl grid-cols-5",
					children: [NAV.filter((item) => item.primary).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
						item,
						active: tab === item.id,
						onClick: () => open(item.id),
						stacked: true
					}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setMore(true),
						className: cx("flex min-h-14 flex-col items-center justify-center gap-0.5 text-xs font-semibold", !NAV.find((item) => item.id === tab)?.primary ? "text-teal" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
							className: "size-5",
							"aria-hidden": true
						}), "More"]
					})]
				})
			}),
			more && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Close menu",
					className: "absolute inset-0 bg-ink/40",
					onClick: () => setMore(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "safe-dock absolute inset-x-0 bottom-0 rounded-t-3xl border border-line bg-card px-4 pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: "More"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Close",
							className: "inline-flex size-11 items-center justify-center",
							onClick: () => setMore(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-1 pb-2",
						children: NAV.filter((item) => !item.primary).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							item,
							active: tab === item.id,
							onClick: () => open(item.id)
						}, item.id))
					})]
				})]
			})
		]
	});
}
function Stat({ value, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-card px-2 py-2 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
			className: "block text-lg leading-none font-extrabold tabular-nums",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 block text-xs text-muted",
			children: label
		})]
	});
}
function NavButton({ item, active, onClick, stacked }) {
	const Icon = item.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		"aria-current": active ? "page" : void 0,
		className: cx(stacked ? "flex min-h-14 flex-col items-center justify-center gap-0.5 px-1 text-xs font-semibold" : "flex min-h-11 items-center gap-2 rounded-xl px-3 text-left text-sm font-semibold", active ? "bg-teal text-teal-ink" : "text-ink"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-5 shrink-0",
			"aria-hidden": true
		}), item.label]
	});
}
function nextTheme(theme, dark) {
	if (theme === "system") return dark ? "light" : "dark";
	return theme === "dark" ? "light" : "dark";
}
function Home() {
	const hydrate = useAcademy((s) => s.hydrate);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Academy, {});
}
//#endregion
export { Home as component };
