//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D4uEx0vW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-C-uyeXGh.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C-uyeXGh.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-g56GY63G.js"]
	}
} });
//#endregion
export { tsrStartManifest };
